from django.contrib import admin
from .models import Ebook

admin.site.register(Ebook)

